import java.util.Scanner;

public class acad {
	
	public static void main(String ar[])
	{
			Scanner S = new Scanner (System.in);
			int a,b;
			System.out.println ("Enter First Number ");
			a = S.nextInt();
			System.out.println ("Enter Second  Number ");
			b = S.nextInt();
			int c=a+b;
			System.out.println ("Addition " + c);
	}

}