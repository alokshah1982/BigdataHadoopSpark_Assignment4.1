
public class acad {

	public static void Sum(int x,int y)
	{
		System.out.println("Addition " + (x+y));
	}
	
	public static void Sum(double x,double y)
	{
		System.out.println("Addition " + (x+y));
	}

	public static void main (String ar[])
	{
		Sum (10,20);
		Sum(23.34,30.10);
	}
}
